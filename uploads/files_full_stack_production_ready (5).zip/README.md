# FILES Fullstack Production Ready

## Starta med Docker Compose

```
docker-compose up --build
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/api/v1