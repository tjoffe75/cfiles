from fastapi import APIRouter

router = APIRouter()

@router.get("/health")
async def health():
    return {"status": "ok"}

@router.post("/upload")
async def upload_file():
    return {"message": "File uploaded"}