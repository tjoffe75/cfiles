from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from authlib.integrations.starlette_client import OAuth
from starlette.config import Config

router = APIRouter()
config = Config(".env")
oauth = OAuth(config)

oauth.register(
    name='oidc',
    client_id=config('OIDC_CLIENT_ID'),
    client_secret=config('OIDC_CLIENT_SECRET'),
    server_metadata_url=config('OIDC_METADATA_URL'),
    client_kwargs={
        'scope': 'openid email profile',
    }
)

@router.get("/login")
async def login(request: Request):
    redirect_uri = request.url_for('auth_callback')
    return await oauth.oidc.authorize_redirect(request, redirect_uri)

@router.get("/callback")
async def auth_callback(request: Request):
    token = await oauth.oidc.authorize_access_token(request)
    userinfo = await oauth.oidc.parse_id_token(request, token)
    if not userinfo:
        raise HTTPException(status_code=401, detail="Authentication failed")
    return JSONResponse(userinfo)