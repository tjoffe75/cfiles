from pydantic import BaseModel
from typing import Optional
from uuid import UUID
from datetime import datetime

class FileScan(BaseModel):
    id: UUID
    filename: str
    status: Optional[str]
    virus_result: Optional[dict]
    checksum_results: Optional[dict]
    created_at: datetime