import pika
import json
import subprocess
import os
from datetime import datetime
import uuid
from backend.app.database import SessionLocal
from backend.app.models.file import Scan

RABBITMQ_URL = "amqp://guest:guest@rabbitmq:5672/"
QUEUE_NAME = "virus_scan_queue"

def scan_file_with_clamav(file_path: str) -> dict:
    try:
        result = subprocess.run(
            ["clamscan", "--no-summary", file_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        output = result.stdout.strip()
        if "OK" in output:
            return {"infected": False, "result": output}
        else:
            return {"infected": True, "result": output}
    except Exception as e:
        return {"infected": None, "error": str(e)}

def callback(ch, method, properties, body):
    message = json.loads(body)
    file_path = message.get("file_path")
    file_id = message.get("file_id")
    filename = message.get("filename")

    if not file_path or not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        ch.basic_ack(delivery_tag=method.delivery_tag)
        return

    scan_result = scan_file_with_clamav(file_path)

    session = SessionLocal()
    try:
        scan = session.query(Scan).filter(Scan.id == uuid.UUID(file_id)).first()
        if not scan:
            scan = Scan(id=uuid.UUID(file_id), filename=filename)
        scan.virus_result = scan_result
        scan.status = "scanned"
        session.add(scan)
        session.commit()
        print(f"Virus scan result saved for {file_id}")
    except Exception as e:
        print(f"Error saving virus scan result: {e}")
    finally:
        session.close()

    ch.basic_ack(delivery_tag=method.delivery_tag)

def main():
    connection = pika.BlockingConnection(pika.URLParameters(RABBITMQ_URL))
    channel = connection.channel()
    channel.queue_declare(queue=QUEUE_NAME, durable=True)
    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue=QUEUE_NAME, on_message_callback=callback)
    print("Virus worker started, waiting for messages...")
    channel.start_consuming()

if __name__ == "__main__":
    main()