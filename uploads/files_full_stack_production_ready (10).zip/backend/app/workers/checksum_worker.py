import pika
import json
import hashlib
import os
import uuid
from backend.app.database import SessionLocal
from backend.app.models.file import Scan

RABBITMQ_URL = "amqp://guest:guest@rabbitmq:5672/"
QUEUE_NAME = "checksum_queue"

def calculate_sha256(file_path: str) -> str:
    hash_sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

def callback(ch, method, properties, body):
    message = json.loads(body)
    file_path = message.get("file_path")
    file_id = message.get("file_id")
    filename = message.get("filename")

    if not file_path or not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        ch.basic_ack(delivery_tag=method.delivery_tag)
        return

    checksum = calculate_sha256(file_path)

    session = SessionLocal()
    try:
        scan = session.query(Scan).filter(Scan.id == uuid.UUID(file_id)).first()
        if not scan:
            scan = Scan(id=uuid.UUID(file_id), filename=filename)
        scan.checksum_results = {"sha256": checksum}
        scan.status = scan.status or "scanned"
        session.add(scan)
        session.commit()
        print(f"Checksum saved for {file_id}: {checksum}")
    except Exception as e:
        print(f"Error saving checksum: {e}")
    finally:
        session.close()

    ch.basic_ack(delivery_tag=method.delivery_tag)

def main():
    connection = pika.BlockingConnection(pika.URLParameters(RABBITMQ_URL))
    channel = connection.channel()
    channel.queue_declare(queue=QUEUE_NAME, durable=True)
    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue=QUEUE_NAME, on_message_callback=callback)
    print("Checksum worker started, waiting for messages...")
    channel.start_consuming()

if __name__ == "__main__":
    main()