from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
import aiofiles
import uuid
import pika
import json
from datetime import datetime
from sqlalchemy.orm import Session
from backend.app.models.file import Scan
from backend.app.database import SessionLocal

router = APIRouter()

RABBITMQ_URL = "amqp://guest:guest@rabbitmq:5672/"

def publish_to_queue(message: dict, queue_name: str):
    connection = pika.BlockingConnection(pika.URLParameters(RABBITMQ_URL))
    channel = connection.channel()
    channel.queue_declare(queue=queue_name, durable=True)
    channel.basic_publish(
        exchange='',
        routing_key=queue_name,
        body=json.dumps(message),
        properties=pika.BasicProperties(delivery_mode=2),
    )
    connection.close()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Filnamn saknas")

    file_id = str(uuid.uuid4())
    file_path = f"/tmp/{file_id}_{file.filename}"

    async with aiofiles.open(file_path, 'wb') as out_file:
        content = await file.read()
        await out_file.write(content)

    # Skicka jobb till RabbitMQ
    message = {
        "file_id": file_id,
        "file_path": file_path,
        "filename": file.filename,
        "uploaded_at": datetime.utcnow().isoformat()
    }

    publish_to_queue(message, "virus_scan_queue")
    publish_to_queue(message, "checksum_queue")

    # Spara i DB initialt
    db = next(get_db())
    scan = Scan(id=uuid.UUID(file_id), filename=file.filename, status="queued", created_at=datetime.utcnow())
    db.add(scan)
    db.commit()

    return {"file_id": file_id, "message": "Fil mottagen och skanning initierad."}

@router.get("/scan/{file_id}")
def get_scan_result(file_id: uuid.UUID, db: Session = Depends(get_db)):
    scan = db.query(Scan).filter(Scan.id == file_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return {
        "file_id": str(scan.id),
        "filename": scan.filename,
        "status": scan.status,
        "virus_result": scan.virus_result,
        "checksum_results": scan.checksum_results,
        "created_at": scan.created_at,
    }