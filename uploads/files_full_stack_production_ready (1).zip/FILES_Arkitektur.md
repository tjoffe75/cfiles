
# 📚 Arkitekturöversikt – FILES (Uppdaterad 2025-06-24)

## ✅ Implementerat

### 🎨 Frontend (React + Vite)
- Vite-baserad React-app med TypeScript.
- Dynamisk logotyp (kan laddas upp via adminpanel).
- Viseras globalt via `Header`-komponent.
- Komponentstruktur med `AdminPanel`, `LogoUploader`, `FileUpload`, `LogViewer` etc.
- Byggs med Docker (Node 20 Alpine).

### 🧠 Backend (FastAPI)
- FastAPI-baserad tjänst med JWT-stöd.
- OpenID Connect för on-prem AD-integration.
- Endpoints för:
  - Filuppladdning
  - Konfigurationshantering (t.ex. Maintenance, RBAC, SSO)
  - Logotypuppladdning (POST `/admin/logo`)
  - Logotypvisning (GET `/branding/logo.png`)
- Dockerfile för production + auto-migration via Alembic.

### ⚙️ Workers
- Docker-baserade workers för:
  - Virusanalys (ClamAV, ej implementerat ännu)
  - Checksummor
- Baseras på Python 3.11 + pika

### 🐘 Databas & Köer
- PostgreSQL med schema:
  - `scans`
  - `admin_config`
- RabbitMQ för meddelandehantering mellan API och workers.

### 🗂 Docker Compose
- En docker-compose.yml som kör:
  - frontend
  - backend
  - postgres
  - rabbitmq
  - virus-worker
  - checksum-worker

### 🧪 Test & Utveckling
- `pytest`-testmiljö för backend.
- `.env` och `.env.example` ingår.
- `start_files_app.bat` för Windows-starter.

---

## ⏳ Återstår att implementera

### 🔐 AD-integrationen (OpenID Connect mot on-prem AD)
- Endast arkitekturstöd i nuläget.
- Inga kodade endpoints än.

### 🧼 Karantänfunktion
- Filstatus "quarantined" stöds logiskt.
- Behöver UI-komponent i adminpanelen.

### 🛑 Maintenance Mode & RBAC
- Finns i API-design.
- Konfigvärden sparas i `admin_config`, men UI ännu ej implementerat.

### 📄 Loggvisning i Adminpanel
- Endpoint `/admin/logs` återstår.
- UI-komponent finns delvis.

### 🔧 CI/CD & Övervakning
- GitHub Actions-pipelines saknas.
- Elastic Stack / Prometheus ännu ej integrerat.

---

## 🚀 Nästa steg (föreslaget)
1. Implementera OIDC-inloggning med testbar konfiguration.
2. Adminpanel: karantänhantering, maintenance-läge och loggläsare.
3. Färdigställ logik i workers (virus scan).
4. CI/CD pipeline med GitHub Actions.
5. Logghantering via Elastic eller Prometheus.
