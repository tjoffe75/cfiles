from pydantic import BaseModel
from datetime import datetime

class AdminConfig(BaseModel):
    key: str
    value: dict
    updated_at: datetime